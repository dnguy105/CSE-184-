import React from "react";
import "./SelectedCereal.css"

class SelectedCereal extends React.Component {
  constructor(props) {
    super(props);
    this.formatList = this.formatList.bind(this);
  }

  formatList(ingredients) {
    let output = "";

    if(ingredients.length === 0 || ingredients === " ") {
      return '';
    }

    let splitIngredients = ingredients.split(',');

    for (let i=0; i<4; i++) {
      output = output + splitIngredients[i] + ",";
    }
    output = output + splitIngredients[4];
    return output;
  }

  render(props) {
    return (
      <div className="selected-cereal">
        <div id="nut_overview">Nutritional Overview</div>
          <div id="line"> </div>
          <div id="nut_wrapper">
            <div id="second"> Name: </div>
            <div id="third"> {this.props.selectedCereal.name} </div>
          </div>
          <div id="line2"> </div>
          <div id="nut_wrapper">
            <div id="second"> Cups: </div>
            <div id="third"> 1.5 </div>
          </div>
          <div id="line2"> </div>
          <div id="nut_wrapper">
            <div id="second"> Health Score: </div>
            <div id="third"> { Math.round(this.props.selectedCereal.health_score*100)/100} </div>
          </div>
          <div id="line2"> </div>
          <div id="nut_wrapper">
            <div id="second"> Sugars (g):</div>
            <div id="third"> {this.props.selectedCereal.sugars} </div>
          </div>
          <div id="line2"> </div>
          <div id="nut_wrapper">
            <div id="second"> Calories (cal): </div>
            <div id="third"> {this.props.selectedCereal.calories} </div>
          </div>
          <div id="line2"> </div>
          <div id="nut_wrapper">
            <div id="second"> Fat (g): </div>
            <div id="third"> {this.props.selectedCereal.fat} </div>
          </div>
          <div id="line2"> </div>
          <div id="nut_wrapper">
            <div id="second"> Sodium (mg): </div>
            <div id="third"> {this.props.selectedCereal.sodium} </div>
          </div>
          <div id="line2"> </div>
          <div id="nut_wrapper">
            <div id="second"> Protein (g): </div>
            <div id="third"> {this.props.selectedCereal.protein} </div>
          </div>
          <div id="line2"> </div>
          <div id="nut_wrapper">
            <div id="second"> Fiber (g): </div>
            <div id="third"> {this.props.selectedCereal.fiber} </div>
          </div>
          <div id="line2"> </div>
          <div id="nut_wrapper">
            <div id="second"> Vitamins (%): </div>
            <div id="third"> {this.props.selectedCereal.vitamins} </div>
          </div>
          <div id="line2"> </div>
          <div id="nut_wrapper">
            <div id="second"> First 5 ingredients: </div>
            <div id="third"> {this.formatList(this.props.selectedCereal.ingredients)} </div>
          </div>
          <div id="line2"> </div>
          <div id="nut_wrapper">
            <div id="second"> </div>
            {this.props.selectedCereal.vegan && <div id="vegan"> <img src={"https://nutrition.sa.ucsc.edu/LegendImages/vegan.gif"} /> Vegan</div>}
            {this.props.selectedCereal.gluten && <div id="gluten"><img src={"https://nutrition.sa.ucsc.edu/LegendImages/gluten.gif"} /> Gluten Free</div>}
            {this.props.selectedCereal.organic && <div id="organic"><img src={"https://nutrition.sa.ucsc.edu/LegendImages/veggie.gif"} /> Organic</div>}
            
          </div>
    </div>
    )
  }
}

export default SelectedCereal;