import React, { PureComponent } from 'react';
import {
  ComposedChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip,
  Cell, LabelList
} from 'recharts';

export default class BarChart extends PureComponent {

  constructor(props) {
    super(props);
    this.handleClick = this.handleClick.bind(this);
  }


  handleClick = (data, index) => {
    console.log(this.props.cereals[index]);
    console.log(this.props.selected);
    this.props.updateSelected(this.props.cereals[index]);
  }


  render() {
    let getCerealName = (x) => {
      let output = x.name;
      if(x.vegan) {
        output = output + ' (V)';
      }
      if(x.gluten) {
        output = output + ' (GF)';
      }
      if(x.organic) {
        output = output + ' (O)';
      }
      return output;
    }
    return (
      <ComposedChart
        layout="vertical"
        width={800}
        height={2000}
        data={this.props.cereals}
        margin={{
          top: 30, right: 20, bottom: 20, left: 20,
        }}
      >
        <CartesianGrid stroke="#f5f5f5" />
        <XAxis type="number" 
          orientation="top" 
          label={{value: "Health score", fontSize:"20px", dy: -25}} 
          tick={{dy: -5}}/>
        <YAxis dataKey={getCerealName} type="category" dx={-10} width={250}/>
        <Tooltip />
        <Bar onClick={this.handleClick} dataKey="health_score" barSize={20} fill="#413ea0">
          {
            this.props.cereals.map((entry, index) => (
              <Cell cursor="pointer" fill={entry.selected ? '#82ca9d' : '#8884d8'} key={`cell-${index}`} />
            ))
          }
        </Bar>
      </ComposedChart>
    );
  }
}